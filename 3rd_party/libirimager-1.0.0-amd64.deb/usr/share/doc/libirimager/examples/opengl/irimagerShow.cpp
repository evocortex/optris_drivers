#include <stdio.h>
#include <string.h>
#include <iostream>
#include <pthread.h>
#include <sys/time.h>

/**
 * Optris device interface
 */
#include "IRImager.h"

/**
 * Optris image converter
 */
#include "ImageBuilder.h"

/**
 * Optris frame rate calculation helper
 */
#include "FramerateCounter.h"

/**
 * Visualization
 */
#include "Obvious2D.h"

using namespace std;
using namespace optris;
using namespace obvious;

bool _showVisibleChannel = false;
EnumOptrisColoringPalette _palette = eIron;
bool _biSpectral = false;

pthread_mutex_t _mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  _available = PTHREAD_COND_INITIALIZER;

bool _shutdown = false;

// Threaded working function to display images
void* displayWorker(void* arg);

unsigned int _w;
unsigned int _h;
unsigned short* _thermal = NULL;
unsigned char* _yuyv = NULL;
FramerateCounter _fpsDisplay(30);

void onThermalFrame(unsigned short* thermal, unsigned int w, unsigned int h, long long timestamp)
{
  pthread_mutex_lock( &_mutex );
  _w = w;
  _h = h;
  if(_thermal==NULL) _thermal = new unsigned short[w*h];
  memcpy(_thermal, thermal, w*h*sizeof(*thermal));
  pthread_cond_signal( &_available );
  pthread_mutex_unlock( &_mutex );
}

void onVisibleFrame(unsigned char* yuyv, unsigned int w, unsigned int h)
{
  if(_showVisibleChannel)
  {
    pthread_mutex_lock( &_mutex );
    _w = w;
    _h = h;
    if(_yuyv==NULL) _yuyv = new unsigned char[w*h*2];
    memcpy(_yuyv, yuyv, 2*w*h*sizeof(*yuyv));
    pthread_cond_signal( &_available );
    pthread_mutex_unlock( &_mutex );
  }
}

void drawMeasurementInfo(Obvious2D* viewer, ImageBuilder* iBuilder, unsigned char* dst, unsigned int w, unsigned int h, unsigned int x, unsigned int y, float value)
{
  char text[20];
  iBuilder->drawCrosshair(dst, x, y, 3);
  sprintf(text, "%2.1f", value);
  unsigned int xOffset = w/20;
  unsigned int yOffset = h/20;

  if(x>xOffset)
    x -= xOffset;

  if(y<h-yOffset)
    y += yOffset;
  else
    y -= yOffset/2;

  unsigned int width = viewer->getWidth();
  unsigned int height = viewer->getHeight();
  viewer->addText(text, width * x/w, height - height * y/h);
}

void drawHelp(Obvious2D* viewer)
{
  _fpsDisplay.trigger();
  char text1[64];
  sprintf(text1, "%d fps", (unsigned int)((_fpsDisplay.getMeanValue())+ 0.5));
  char text2[] = "p: Switch palette";
  char text3[] = "t: Toggle thermal/visible channel";
  unsigned int width = viewer->getWidth();
  unsigned int height = viewer->getHeight();
  viewer->addText(text1, width - 320, height - 20);
  viewer->addText(text2, width - 320, height - 40);
  if(_biSpectral) viewer->addText(text3, width - 320, height - 60);
}

void cbPalette()
{
  unsigned int val = (unsigned int)_palette;
  if((val++)>eAlarmRed) val = 1;
  _palette = (EnumOptrisColoringPalette) val;
}

void cbChannel()
{
  _showVisibleChannel = !_showVisibleChannel;
}

void* displayWorker(void* arg)
{
  obvious::Obvious2D viewer(960, 600, "Optris Imager example");
  viewer.registerKeyboardCallback('p', cbPalette);
  viewer.registerKeyboardCallback('t', cbChannel);

  ImageBuilder iBuilder;
  iBuilder.setPaletteScalingMethod(eMinMax);
  iBuilder.setManualTemperatureRange(15.0f, 40.0f);
  _palette = iBuilder.getPalette();

  unsigned char* bufferThermal  = NULL;
  unsigned char* bufferVisible = NULL;

  while(viewer.isAlive())
  {
    pthread_mutex_lock( &_mutex );
    pthread_cond_wait( &_available, &_mutex );

    int w = _w;
    int h = _h;

    viewer.clearText();
    drawHelp(&viewer);
    iBuilder.setPalette(_palette);

    if(_showVisibleChannel)
    {
      if(bufferVisible==NULL)
        bufferVisible = new unsigned char[w * h * 3];
      iBuilder.yuv422torgb24(_yuyv, bufferVisible, w, h);
      pthread_mutex_unlock( &_mutex );
      viewer.draw(bufferVisible, w, h, 3);
    }
    else
    {
      iBuilder.setData(w, h, _thermal);
      if(bufferThermal==NULL)
        bufferThermal = new unsigned char[iBuilder.getStride() * h * 3];

      iBuilder.convertTemperatureToPaletteImage(bufferThermal);
      pthread_mutex_unlock( &_mutex );

      int radius = 3;
      ExtremalRegion minRegion;
      ExtremalRegion maxRegion;
      iBuilder.getMinMaxRegion(radius, &minRegion, &maxRegion);
      drawMeasurementInfo(&viewer, &iBuilder, bufferThermal, w, h, (minRegion.u1+minRegion.u2)/2, (minRegion.v1+minRegion.v2)/2, minRegion.t);
      drawMeasurementInfo(&viewer, &iBuilder, bufferThermal, w, h, (maxRegion.u1+maxRegion.u2)/2, (maxRegion.v1+maxRegion.v2)/2, maxRegion.t);

      viewer.draw(bufferThermal, iBuilder.getStride(), _h, 3);
    }
  }

  if(bufferThermal) delete [] bufferThermal;
  if(bufferVisible) delete [] bufferVisible;
  _shutdown = true;
}

int main (int argc, char* argv[])
{
  if(argc!=2)
  {
    cout << "usage: " << argv[0] << " <xml configuration file>" << endl;
    return -1;
  }

  /**
   * Initialize Optris image processing chain
   */
  IRImager imager(argv[1]);
  if(imager.getWidth()==0 || imager.getHeight()==0)
  {
    cout << "Error: Image streams not available or wrongly configured. Check connection of camera and config file." << endl;
    return -1;
  }

  cout << "Connected camera, serial: " << imager.getSerial() << ", HW(Rev.): " << imager.getHWRevision() << ", FW(Rev.): " << imager.getFWRevision() << endl;

  cout << "Thermal channel: " << imager.getWidth() << "x" << imager.getHeight() << "@" << imager.getFramerate() << "Hz" << endl;

  unsigned char* bufferRaw = new unsigned char[imager.getRawBufferSize()];

  _biSpectral = imager.hasBispectralTechnology();
  if(_biSpectral)
    cout << "Visible channel: " << imager.getVisibleWidth() << "x" << imager.getVisibleHeight() << "@" << imager.getFramerate() << "Hz" << endl;

  imager.setFrameCallback(onThermalFrame);
  imager.setVisibleFrameCallback(onVisibleFrame);

  pthread_t th;
  pthread_create( &th, NULL, displayWorker, NULL);

  /**
   * Enter endless loop in order to pass raw data to Optris image processing library.
   * Processed data are supported by the frame callback function.
   */
  imager.startStreaming();
  FramerateCounter fpsStream;

  while(!_shutdown)
  {
    if(imager.getFrame(bufferRaw))
    {
      imager.process(bufferRaw);
      imager.releaseFrame();
      fpsStream.trigger();
      fpsStream.printMean(1000.0, cout);
    }
  }

  delete [] bufferRaw;

  cout << "Exiting application" << endl;
}
