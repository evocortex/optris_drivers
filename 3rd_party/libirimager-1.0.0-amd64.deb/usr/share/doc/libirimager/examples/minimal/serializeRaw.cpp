#include <stdio.h>
#include <string.h>
#include <iostream>
#include <pthread.h>
#include <sys/time.h>
#include <fstream>

/**
 * Optris interface
 */
#include "IRImager.h"

/**
 * Optris frame rate calculation helper
 */
#include "FramerateCounter.h"

using namespace std;
using namespace optris;

pthread_mutex_t   _mutex     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t    _available = PTHREAD_COND_INITIALIZER;

unsigned int      _w;
unsigned int      _h;
unsigned short*   _image          = NULL;
unsigned long     _serial         = 0;
unsigned int      _cntGrab        = 0;
unsigned int      _cntSerialize   = 0;
bool              _serializerIdle = false;
FramerateCounter  _fpsSerialize(1000);

long long _timestamps[1000];

// Threaded working function to serialize images
void* serializationWorker(void* arg);

// Callback function for indicating availability of thermal data
void onThermalFrame(unsigned short* image, unsigned int w, unsigned int h, long long timestamp);

int main (int argc, char* argv[])
{
  if(argc!=2)
  {
    cout << "usage: " << argv[0] << " <xml configuration file>" << endl;
    return -1;
  }

  /**
   * Initialize Optris image processing chain
   */
  IRImager imager(argv[1]);
  if(imager.getWidth()==0 || imager.getHeight()==0)
  {
    cout << "Error: Image streams not available or wrongly configured. Check connection of camera and config file." << endl;
    return -1;
  }

  _serial = imager.getSerial();

  cout << "Thermal channel: " << imager.getWidth() << "x" << imager.getHeight() << "@" << imager.getMaxFramerate() << "Hz" << endl;

  unsigned char* bufferRaw = new unsigned char[imager.getRawBufferSize()];

  imager.setFrameCallback(onThermalFrame);

  pthread_t th;
  pthread_create( &th, NULL, serializationWorker, NULL);

  /**
   * Enter endless loop in order to pass raw data to Optris image processing library.
   * Processed data are supported by the frame callback function.
   */
  imager.startStreaming();

  while(_cntSerialize<1000)
  {
    if(imager.getFrame(bufferRaw))
    {
      imager.process(bufferRaw);
      imager.releaseFrame();
    }
  }

  delete [] bufferRaw;

  //_fpsSerialize.printQueue(cout);

  cout << "Exiting application" << endl;
  cout << "Grabbed " << _cntGrab << " images, serialized " << _cntSerialize << " images";

  cout << "timestamps" << endl;
  for(int i=1; i<1000; i++)
    cout << _timestamps[i]-_timestamps[i-1] << endl;
}

void onThermalFrame(unsigned short* image, unsigned int w, unsigned int h, long long timestamp)
{
  pthread_mutex_lock( &_mutex );
  _w = w;
  _h = h;
  _cntGrab++;
  if(_image==NULL) _image = new unsigned short[w*h];
  if(_serializerIdle)
  {
    _cntSerialize = _cntGrab;
    memcpy(_image, image, w*h*sizeof(*image));
    pthread_cond_signal( &_available );
    _fpsSerialize.trigger();
    _timestamps[_cntSerialize] = timestamp;
  }
  pthread_mutex_unlock( &_mutex );
  //_fpsSerialize.printMean(1000.0, cout);
}

void* serializationWorker(void* arg)
{
  char filename[64];

  while(1)
  {
    pthread_mutex_lock( &_mutex );
    _serializerIdle = true;
    pthread_cond_wait( &_available, &_mutex );
    _serializerIdle = false;
    sprintf(filename, "/tmp/image_%ld_%05d.raw", _serial, _cntSerialize);
    pthread_mutex_unlock( &_mutex );
    // Write data
    ofstream f;
    f.open(filename, ios::out | ios::binary);
    f.write((const char*)_image, _w*_h*sizeof(*_image));
    f.close();
  }

  return NULL;
}
