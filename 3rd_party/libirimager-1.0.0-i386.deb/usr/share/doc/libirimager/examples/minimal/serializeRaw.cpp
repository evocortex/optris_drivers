#include <stdio.h>
#include <string.h>
#include <iostream>
#include <pthread.h>
#include <sys/time.h>
#include <fstream>

#include <vector>
#include <list>

/**
 * Optris interface
 */
#include "IRImager.h"

using namespace std;
using namespace optris;

pthread_mutex_t   _mutex  = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t    _available = PTHREAD_COND_INITIALIZER;

unsigned int      _w;
unsigned int      _h;
unsigned long     _serial         = 0;

std::list<unsigned short*> _images;
std::list<long long> _timestamps;
std::vector<double> _runtime;

#define QUEUE_LENGTH 10

unsigned int _cntSerialized = 0;
unsigned int _cntDropped = 0;

// Threaded function to serialize images
void* serializationWorker(void* arg);

// Callback function indicating availability of thermal data
void onThermalFrame(unsigned short* image, unsigned int w, unsigned int h, long long timestamp);

int main (int argc, char* argv[])
{
  if(argc!=2)
  {
    cout << "usage: " << argv[0] << " <xml configuration file>" << endl;
    return -1;
  }

  /**
   * Initialize Optris image processing chain
   */
  IRImager imager(argv[1]);
  if(imager.getWidth()==0 || imager.getHeight()==0)
  {
    cout << "Error: Image streams not available or wrongly configured. Check connection of camera and config file." << endl;
    return -1;
  }

  _serial = imager.getSerial();

  cout << "Thermal channel: " << imager.getWidth() << "x" << imager.getHeight() << "@" << imager.getMaxFramerate() << "Hz" << endl;

  unsigned char* bufferRaw = new unsigned char[imager.getRawBufferSize()];

  imager.setFrameCallback(onThermalFrame);

  pthread_t th;
  pthread_create( &th, NULL, serializationWorker, NULL);

  /**
   * Enter endless loop in order to pass raw data to Optris image processing library.
   * Processed data are supported by the frame callback function.
   */
  imager.startStreaming();


  while(_cntSerialized<5000)
  {
    if(imager.getFrame(bufferRaw))
    {
      imager.process(bufferRaw);
      imager.releaseFrame();
    }
  }

  delete [] bufferRaw;

  cout << "Serialized " << _cntSerialized << " images, dropped " << _cntDropped << " images" << endl;

  cout << "Runtime: " << endl;
  for(int i=1; i<_runtime.size(); i++)
    cout << _runtime[i] << endl;
}

void onThermalFrame(unsigned short* image, unsigned int w, unsigned int h, long long timestamp)
{
  _w = w;
  _h = h;
  unsigned short* img = new unsigned short[_w*_h];
  memcpy(img, image, w*h*sizeof(*image));
  pthread_mutex_lock( &_mutex );
  _images.push_back(img);
  _timestamps.push_back(timestamp);
  pthread_cond_signal( &_available );
  pthread_mutex_unlock( &_mutex );
}

void* serializationWorker(void* arg)
{
  char filename[64];

  unsigned int cnt = 0;
  while(1)
  {
    pthread_mutex_lock( &_mutex );
    if(_images.empty()) pthread_cond_wait( &_available, &_mutex );
    pthread_mutex_unlock( &_mutex );

    // Write data
    unsigned short* img = _images.front();
    if(_images.size()<QUEUE_LENGTH)
    {
      long long timestamp = _timestamps.front();
      static long long old_timestamp = timestamp;
      _runtime.push_back(((double)(timestamp-old_timestamp))/10000.0);
      old_timestamp = timestamp;
      sprintf(filename, "/tmp/image_%ld_%05d_%lld.raw", _serial, _cntSerialized+_cntDropped, timestamp);
      ofstream f;
      f.open(filename, ios::out | ios::binary);
      f.write((const char*)img, _w*_h*sizeof(*img));
      f.close();
      _cntSerialized++;
    }
    else
    {
      cout << "Warning: Serialization too slow ... dropping frame" << endl;
      _cntDropped++;
    }
    delete [] img;
    pthread_mutex_lock( &_mutex );
    _images.pop_front();
    _timestamps.pop_front();
    pthread_mutex_unlock( &_mutex );
  }

  return NULL;
}
